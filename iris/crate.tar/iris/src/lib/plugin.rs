/// Plugin module for the IRC server.
/// 
/// To add a plugin into the server, you can just simply define your function and
/// add the plugin name into the PLUGIN_LIST object and the get_plugin function.
use std::{sync::{Mutex, Arc}, collections::HashMap};

use crate::user::User;

/// Array to store all the plugin names. 
/// 
/// When you want to add a plugin into the server, please do not forget to 
/// add the name of plugin into the array.
/// For example, if you want to add a plugin named "timer"
/// Your should modify it to the following code
/// ```
/// const PLUGIN_LSIT: [&'static str; 1] = ["timer"];
/// ```
const PLUGIN_LSIT: [&'static str; 2] = ["reminder", "count5s"];

/// Get the plugin function by its name
/// 
/// When you want to add a plugin into the server, please return the corresponding 
/// add the name of plugin into the array.
/// /// For example, if you want to add a plugin named "timer"
/// Your should modify it to the following code
/// ```
/// pub fn get_plugin(plugin_name: String) -> impl FnOnce(Arc<Mutex<Vec<User>>>, Arc<Mutex<HashMap<String, Vec<String>>>>, String)->() + std::marker::Send
/// {
///     if plugin_name = "timer" {
///         return timer_plug_in;
///     }
///     return reminder_plug_in;
/// }
/// 
/// 
/// ```
pub fn get_plugin(plugin_name: String) -> 
impl FnOnce(Arc<Mutex<Vec<User>>>, Arc<Mutex<HashMap<String, Vec<String>>>>, String)->() + std::marker::Send
{
    if plugin_name == "reminder" {
        return reminder_plug_in;
    }
    return reminder_plug_in;
}

/// Generate a thread for the plugin to run
pub fn generate_thread<F>(f: F, users: Arc<Mutex<Vec<User>>>, channels: Arc<Mutex<HashMap<String, Vec<String>>>>, sender_id: String)
where F : FnOnce(Arc<Mutex<Vec<User>>>, Arc<Mutex<HashMap<String, Vec<String>>>>, String)->() + std::marker::Send + 'static
{
    std::thread::spawn(move || {
       f(users, channels, sender_id);
    });
}

/// Check if the receiver is a plugin
pub fn is_a_plugin_name(receiver_nick: &String) -> bool {
    match PLUGIN_LSIT.iter().find(|plugin_name| plugin_name == &receiver_nick) {
        Some(_) => true,
        None => false,
    }
}

/// Example plugin 1.
/// 
/// Send message to the user for every 5 seconds.
fn reminder_plug_in(users: Arc<Mutex<Vec<User>>>, _channels: Arc<Mutex<HashMap<String, Vec<String>>>>, sender_id: String) 
{
    loop {
        std::thread::sleep(std::time::Duration::from_secs(5));
        let mut users = users.as_ref().lock().unwrap();
        let receiver = users.iter_mut().find(|usr| usr.get_id() == *sender_id);
        let receiver = match receiver {
            Some(res) => res,
            None => break,
        };
        let message = &format!(
            "This is a reminder.\r\n",
        );
        let _ = receiver.get_conn_write().write_message(message);
    }
}

/// Example plugin 2.
/// 
/// Send message to the user to tell them times up.
fn count_5_seconds(users: Arc<Mutex<Vec<User>>>, _channels: Arc<Mutex<HashMap<String, Vec<String>>>>, sender_id: String) 
{
    std::thread::sleep(std::time::Duration::from_secs(5));
    let mut users = users.as_ref().lock().unwrap();
    let receiver = users.iter_mut().find(|usr| usr.get_id() == *sender_id);
    let receiver = match receiver {
        Some(res) => res,
        None => {
            return;
        },
    };
    let message = &format!(
        "Times up!.\r\n",
    );
    let _ = receiver.get_conn_write().write_message(message);
}

