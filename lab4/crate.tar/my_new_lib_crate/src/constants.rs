pub const DEFAULT_NUM: u8 = 10;
pub const ERROR_MESSAGE: &str = "Please enter a valid size";